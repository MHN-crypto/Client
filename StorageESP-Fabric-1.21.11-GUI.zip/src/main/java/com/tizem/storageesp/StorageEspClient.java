package com.tizem.storageesp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.debug.DebugRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class StorageEspClient implements ClientModInitializer {
    public static boolean esp = true;
    public static boolean tracers = false;
    public static boolean stashFinder = false;
    public static boolean flight = false;
    public static boolean freecam = false;
    public static double range = 96.0;

    private static KeyBinding menuKey;
    private static final List<MarkedBlock> cache = new ArrayList<>();
    private static int scanTimer = 0;

    @Override
    public void onInitializeClient() {
        // O opens the GUI. Feature toggles themselves are controlled by clicking the GUI.
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.storageesp.open_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, "Storage ESP"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                client.setScreen(new StorageEspScreen());
            }

            if (++scanTimer >= 10) {
                scanTimer = 0;
                scan(client);
            }
            if (client.player != null && flight) {
                client.player.getAbilities().allowFlying = true;
                client.player.getAbilities().flying = true;
            }
        });

        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            if (!esp && !stashFinder && !tracers) return;
            MatrixStack matrices = context.matrices();
            VertexConsumerProvider consumers = context.consumers();
            if (matrices == null || consumers == null) return;
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;
            Vec3d camera = context.gameRenderer().getMainCamera().getPos();
            matrices.push();
            matrices.translate(-camera.x, -camera.y, -camera.z);
            for (MarkedBlock marked : cache) {
                double d2 = marked.pos.getSquaredDistance(camera);
                if (d2 > range * range) continue;
                if ((esp || (stashFinder && marked.storage)) && marked.storage || (esp && !marked.storage)) {
                    DebugRenderer.drawBox(matrices, consumers, marked.pos,
                            colorR(marked.block), colorG(marked.block), colorB(marked.block), 0.85f);
                }
                if (tracers) {
                    BlockPos start = new BlockPos((int) Math.floor(camera.x), (int) Math.floor(camera.y), (int) Math.floor(camera.z));
                    DebugRenderer.drawBox(matrices, consumers, start, marked.pos,
                            colorR(marked.block), colorG(marked.block), colorB(marked.block), 0.35f);
                }
            }
            matrices.pop();
        });
    }

    private static void scan(MinecraftClient client) {
        ClientWorld world = client.world;
        if (world == null) { cache.clear(); return; }
        Set<BlockEntity> entities = world.getBlockEntities();
        Vec3d center = client.player == null ? Vec3d.ZERO : client.player.getPos();
        List<MarkedBlock> next = new ArrayList<>();
        for (BlockEntity entity : entities) {
            Block block = entity.getCachedState().getBlock();
            if (!isTarget(block)) continue;
            BlockPos pos = entity.getPos();
            if (pos.getSquaredDistance(center) <= range * range) {
                next.add(new MarkedBlock(pos.toImmutable(), block, isStorage(block)));
            }
        }
        cache.clear();
        cache.addAll(next);
    }

    private static boolean isTarget(Block b) {
        return isStorage(b) || b == Blocks.SPAWNER;
    }

    private static boolean isStorage(Block b) {
        return b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST || b == Blocks.BARREL ||
                b == Blocks.FURNACE || b == Blocks.BLAST_FURNACE || b == Blocks.SMOKER ||
                b == Blocks.HOPPER || isShulker(b);
    }

    private static boolean isShulker(Block b) {
        return b == Blocks.SHULKER_BOX || b == Blocks.WHITE_SHULKER_BOX || b == Blocks.ORANGE_SHULKER_BOX ||
                b == Blocks.MAGENTA_SHULKER_BOX || b == Blocks.LIGHT_BLUE_SHULKER_BOX || b == Blocks.YELLOW_SHULKER_BOX ||
                b == Blocks.LIME_SHULKER_BOX || b == Blocks.PINK_SHULKER_BOX || b == Blocks.GRAY_SHULKER_BOX ||
                b == Blocks.LIGHT_GRAY_SHULKER_BOX || b == Blocks.CYAN_SHULKER_BOX || b == Blocks.PURPLE_SHULKER_BOX ||
                b == Blocks.BLUE_SHULKER_BOX || b == Blocks.BROWN_SHULKER_BOX || b == Blocks.GREEN_SHULKER_BOX ||
                b == Blocks.RED_SHULKER_BOX || b == Blocks.BLACK_SHULKER_BOX;
    }

    private static float colorR(Block b) { return b == Blocks.SPAWNER ? 1f : b == Blocks.HOPPER ? 0.8f : 0.2f; }
    private static float colorG(Block b) { return b == Blocks.SPAWNER ? 0.1f : b == Blocks.FURNACE ? 0.6f : 0.9f; }
    private static float colorB(Block b) { return b == Blocks.SPAWNER ? 0.8f : b == Blocks.CHEST ? 0.1f : 0.2f; }

    private record MarkedBlock(BlockPos pos, Block block, boolean storage) {}

    public static class StorageEspScreen extends Screen {
        private final Screen parent;

        public StorageEspScreen() {
            this(null);
        }

        public StorageEspScreen(Screen parent) {
            super(Text.literal("Storage ESP"));
            this.parent = parent;
        }

        @Override
        protected void init() {
            int centerX = this.width / 2;
            int y = 48;
            int w = 220;
            int h = 22;
            int gap = 26;

            addToggle(centerX - w / 2, y, w, h, "Storage ESP", () -> esp, v -> esp = v);
            addToggle(centerX - w / 2, y += gap, w, h, "Tracers", () -> tracers, v -> tracers = v);
            addToggle(centerX - w / 2, y += gap, w, h, "Stash Finder", () -> stashFinder, v -> stashFinder = v);
            addToggle(centerX - w / 2, y += gap, w, h, "Flight", () -> flight, v -> flight = v);
            addToggle(centerX - w / 2, y += gap, w, h, "Freecam", () -> freecam, v -> freecam = v);

            int rangeY = y + 38;
            addDrawableChild(ButtonWidget.builder(Text.literal("ESP Range: " + (int) range), b -> {
                range = range >= 128 ? 32 : range + 32;
                b.setMessage(Text.literal("ESP Range: " + (int) range));
            }).dimensions(centerX - w / 2, rangeY, w, h).build());

            addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                    .dimensions(centerX - 75, rangeY + 34, 150, h).build());
        }

        private void addToggle(int x, int y, int w, int h, String name,
                               java.util.function.BooleanSupplier getter,
                               java.util.function.Consumer<Boolean> setter) {
            ButtonWidget button = ButtonWidget.builder(toggleText(name, getter.getAsBoolean()), b -> {
                boolean next = !getter.getAsBoolean();
                setter.accept(next);
                b.setMessage(toggleText(name, next));
            }).dimensions(x, y, w, h).build();
            addDrawableChild(button);
        }

        private static Text toggleText(String name, boolean enabled) {
            return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            context.fill(0, 0, this.width, this.height, 0xCC0B0E12);
            int centerX = this.width / 2;
            context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("STORAGE ESP"), centerX, 18, 0xFFFFFF);
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal("Click features to toggle them"), centerX, 32, 0xAAB0B8);
            super.render(context, mouseX, mouseY, delta);
        }

        @Override
        public void close() {
            MinecraftClient.getInstance().setScreen(parent);
        }
    }
}
